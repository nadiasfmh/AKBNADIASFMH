package com.example.a10119278uts.ui.gallery;

/*
NIM     : 10119278
Nama    : Nadia Siti Fatimah
Kelas   : IF-7
 */

public class ModelGallery {
    int image;

    public ModelGallery(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
